<!DOCTYPE HTML >
<html>
<head><title>modif1</title></head>
<body>
<?php
/*Abrir Conexión*/
$linea1="SELECT * FROM cpup ";
$consulta=$linea1;
/*Abrir Conexión*/
$link=mysqli_connect('localhost','Components','1234')  or die("Error " . mysqli_error());
$base=mysqli_select_db($link,"precios")  or die("Error " . mysqli_error()); 
$result=mysqli_query($link,$consulta) or die("Error en la consulta ". mysqli_error());

    $Datos = mysqli_query($link, "SELECT * FROM cpup");
    while($recoger = mysqli_fetch_array($Datos))
    {
        echo $recoger['CPU1'];
    }
/*Cerrar*/
mysqli_close($link);
?>
</body></html>

