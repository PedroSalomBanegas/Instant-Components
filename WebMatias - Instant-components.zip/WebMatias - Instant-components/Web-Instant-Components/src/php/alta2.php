<!DOCTYPE html>
<html>
<head><title>alta2</title></head>
<body>

<?php
$CPU_1 = $_POST['cpu1'];
$CPU_2 = $_POST['cpu2'];
$CPU_3 = $_POST['cpu3'];

$linea1="INSERT INTO CPUp (cpu1, cpu2, cpu3) ";
$linea2=" VALUES ($CPU_1,'$CPU_2', '$CPU_3') ";
$orden=$linea1.$linea2;
print $orden;

if ( ! $link=mysqli_connect('localhost','Components','1234'))      //OJO!!!!    mysqli_connect
{
    print "<a href=index.html>Error al conectar</a>";
    exit ;
}
if ( ! mysqli_select_db($link,"precios"))    // mysqli_select_db($link,"basedatos1"))    
{
    print "<a href=index.html>Error al seleccionar BDD</a>";
    exit;   
}
if ( ! $result=mysqli_query($link,$orden))   //  mysqli_query($link,$orden))   
{
print "<a href=index.html>Error en la orden</a>";
exit;
}
    
mysqli_close($link); 
    
print "<br>Precios subidos correctamente";
print "<br><br><a href='alta.html'>Otra alta</a>";
print "<br><br><a href='index.html'>Inicio</a>";
?>
</body>
</html>


