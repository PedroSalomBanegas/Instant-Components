<!DOCTYPE HTML>
<html>
<head><title>modif2</title></head>
<body>
<?php
$f_modif = $_POST['modif'];
$linea1="SELECT * FROM empresas ";
$linea2=" WHERE id='$f_modif' ";
$consulta=$linea1.$linea2;

$link=mysqli_connect('localhost','pep','1234')  or die("Error " . mysqli_error());
$base=mysqli_select_db($link,"basededatos1")  or die("Error " . mysqli_error()); 
$result=mysqli_query($link,$consulta) or die("Error en la consulta ". mysqli_error());

while($row = mysqli_fetch_assoc($result)) {
    $id = $row['id'];
    $nombre = $row['nombre']; 
    $telef = $row['telef'];
    $sector = $row['sector'];
    //print "<tr><td><INPUT type='radio' name='modif' value='$id'></td><td>$nombre</td></tr>";
}   


?>
<h2>Modifica aqui la empresa</h2>
<form action='modif3.php' method='POST'>
<table border=0>
<tr>
<td>Nombre</td>
<td><input type='text' name='nombre' size='30' maxlength='30' value='<?php print $nombre; ?>' ></td>
</tr>
<tr>
<td>Web</td>
<td><input type='text' name='web' size='30' maxlength='30' value='<?php print $id; ?>'></td>
</tr>
<tr>
<td>Telef</td>
<td><input type='text' name='telef' size='20' maxlength='20' value='<?php print $telef; ?>'></td>
</tr>
<tr>
<td>Sector</td>
<td><input type='text' name='sector' size='30' maxlength='30' value='<?php print $sector; ?>'></td>
</tr>
</table>
<input type='hidden' name='id' value='<?php print $id; ?>'>
<input type='submit' value='Aceptar'>
</form>
<?php
mysqli_close($link);
?>
</body></html>
