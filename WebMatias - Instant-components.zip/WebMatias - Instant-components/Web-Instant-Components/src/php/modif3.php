<!DOCTYPE HTML>
<html>
<head><title>modif3</title></head>
<body>
<?php
    
$f_id = $_POST['id'];
$f_nombre = $_POST['nombre'];
$f_web = $_POST['web'];
$f_telef = $_POST['telef'];
$f_sector = $_POST['nombre'];

$linea1="UPDATE empresas ";
$linea2=" SET nombre='$f_nombre', web='$f_web', telef='$f_telef',sector='$f_sector' ";
$linea3=" WHERE id='$f_id' ";
$consulta=$linea1.$linea2.$linea3;

$link=mysqli_connect('localhost','pep','1234')  or die("Error " . mysqli_error());
$base=mysqli_select_db($link,"basededatos1")  or die("Error " . mysqli_error()); 
$result=mysqli_query($link,$consulta) or die("Error en la consulta ". mysqli_error());
    
print "<br>Modif correcta";
print "<br><br><a href='modif.php'>Otra modif</a>";
print "<br><br><a href='index.html'>Inicio</a>";
mysqli_close($link);
?>
</body>
</html>
