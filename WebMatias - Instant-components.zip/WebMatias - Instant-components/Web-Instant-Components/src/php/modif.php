<!DOCTYPE HTML >
<html>
<head><title>modif1</title></head>
<body>
<?php
$linea1="SELECT * FROM precios ";
$consulta=$linea1;

$link=mysqli_connect('localhost','Components','1234')  or die("Error " . mysqli_error());
$base=mysqli_select_db($link,"precios")  or die("Error " . mysqli_error()); 
$result=mysqli_query($link,$consulta) or die("Error en la consulta ". mysqli_error());
print "<h2>Seleccione empresa/s a dar modificar</h2>";
print "<form action =modif2.php method=POST>";
print "<table border=1>";


while($row = mysqli_fetch_assoc($result)) {
    $CPU_1 = $row['cpu1'];
    $CPU_2 = $row['cpu2']; 
    $CPU_3 = $row['cpu3']; 
    print "<tr><td><INPUT type='radio' name='modif' value='$CPU_1'></td><td>$nombre</td></tr>";
    
 }
/*for ($i=0;$i<mysqli_num_rows($result);$i++)
//{
    $id=mysqli_result($result,1,"id");
    $nombre=mysqli_result($result,1,"nombre");
    print "<tr><td><INPUT type='radio' name='modif' value='$id'></td><td>$nombre</td></tr>";
} */


print "</table>";
print "<input type='submit' value='Modif'>";
print "</form>";
mysqli_close($link);
?>
</body></html>

