<!DOCTYPE html>
<html lang="en">
<head>
    <script src="https://s3.amazonaws.com/stitch-sdks/js/bundles/4.6.0/stitch.js"></script>
    <script>
    const client = stitch.Stitch.initializeDefaultAppClient('jaimestitich-mzfab');

    const db = client.getServiceClient(stitch.RemoteMongoClient.factory, 'JaimeStitchService').db('JaimeDataBasee');

    client.auth.loginWithCredential(new stitch.AnonymousCredential()).then(user =>
    db.collection('JaimeCollectionn').updateOne({owner_id: client.auth.user.id}, {$set:{number:42}}, {upsert:true})
    ).then(() =>
    db.collection('JaimeCollectionn').find({owner_id: client.auth.user.id}, { limit: 100}).asArray()
     ).then(docs => {
      console.log("Found docs", docs)
      console.log("[MongoDB Stitch] Connected to Stitch")
     }).catch(err => {
    console.error(err)
     });
    </script>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <!--Bootstrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <!--Bootstrap-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <title>Instant-Components</title>
</head>
<body>
    
<!-- Barra de Navegación -->
    <nav class="Navegar">
            <ul>
            <div class="posicion">   
                <li class="activa"><a href="#">Inicio</a></li>
                <li><a href="#">Conocenos</a></li>
                <li><a href="">Chats</a></li>
                <li><a href="#">Solicitar</a></li>
                <li><a href="#">Contacta</a></li>
            </div>
            <div id="navimg">
                <a href="index.html"><img src="src/img/LogoFesto.png"></a>
            </div>
            </ul>
    </nav>

<!-- Fin Barra de Navegación -->

    </head>
    <body>
<!-- Contenido Principal-->

    <!-- Slides Info -->
    <section id="hero">
        <div class="hero-container">
          <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">
    
            <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>
    
            <div class="carousel-inner" role="listbox">
    
              <!-- Slide 1 -->
              <div class="carousel-item active" style="background-image: url('src/img/Header1.png');">
                <div class="carousel-container">
                  <div class="carousel-content container"> 
                    <h2 class="animated fadeInDown">¿Solo nos representa el azul?</h2>
                    <p class="animated fadeInUp"><span> No veo el verde </span></p>
                    <a href="#about" class="btn-get-started animated fadeInUp scrollto">Más azul y muero ahogado</a>
                  </div>
                </div>
              </div>
    
              <!-- Slide 2 -->
              <div class="carousel-item" style="background-image: url('src/img/Header2.png');">
                <div class="carousel-container">
                  <div class="carousel-content container">
                    <h2 class="animated fadeInDown">¿Porqué Instant-Components?</h2>
                    <p class="animated fadeInUp">Cambiar texto!!</p>
                    <a href="#services" class="btn-get-started2 animated fadeInUp scrollto">Más información</a>
                  </div>
                </div>
              </div>
            </div>
    
            <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon icofont-rounded-left" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
              <span class="carousel-control-next-icon icofont-rounded-right" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
        </div>
        <main id="main">
      </section>

 <div class="global">
    <form action='src/php/alta2.php' method='POST'>
     <table border=0>
          <tr>
             <td>CPU1</td>
             <td><input type='number' name='cpu1' size='30' maxlength='30'></td>
         </tr>
          <tr>
             <td>CPU2</td>
             <td><input type='number' name='cpu2' size='30' maxlength='30'></td>
          </tr>
          <tr>
              <td>CPU3</td>
             <td><input type='number' name='cpu3' size='30' maxlength='30'></td>
          </tr>
     </table>
     <input type='submit' value='Aceptar'>
     </form>
     <div class="CPU">
     <section>
       <div class="Tcpu">
        <h2>CPU</h2>
      </div>
      </div>
    
   </section>
   <div class="CPU-content">
   <div class="container">    
    <div class="row">
        <div class="boxproducto">
          <div class="producto">Intel</div>
          <div class="imgproducto"><img src="src/img/CPU-I5.png" class="img-responsive" style="width:100%" alt="Image"></div>
          <input type="button" style="text-shadow: 2px 0 0 #fff, -2px 0 0 #fff, 0 2px 0 #fff, 0 -2px 0 #fff, 1px 1px #fff, -1px -1px 0 black, 1px -1px 0 black, -1px 1px 0 black;" value=<?php
/*Abrir Conexión*/
$linea1="SELECT * FROM cpup ";
$consulta=$linea1;
/*Abrir Conexión*/
$link=mysqli_connect('localhost','Components','1234')  or die("Error " . mysqli_error());
$base=mysqli_select_db($link,"precios")  or die("Error " . mysqli_error()); 
$result=mysqli_query($link,$consulta) or die("Error en la consulta ". mysqli_error());

    $Datos = mysqli_query($link, "SELECT * FROM cpup");
    while($recoger = mysqli_fetch_array($Datos))
    {
        echo $recoger['CPU1'];
    }
/*Cerrar*/
mysqli_close($link);
?> class="precio" name="precio11">
    </div>
        <div class="boxproducto">
          <div class="producto">Intel</div>
          <div class="imgproducto"><img src="src/img/CPU-I7.png" class="img-responsive" style="width:100%" alt="Image"></div>
          <div class="precio" name="precio2">???€</div>
        </div>

        <div class="boxproducto">
          <div class="producto">Intel</div>
          <div class="imgproducto"><img src="src/img/CPU-I7.png" class="img-responsive" style="width:100%" alt="Image"></div>
          <div class="precio" name="precio3">???€</div>
        </div>
      </div>
    </div>
  </div>
<!--Cerrado de container y row-->
      
</div> 
</body>
</html>